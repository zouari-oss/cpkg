/**
 * @file      helper.h
 * @author    {{GITHUB_PROFILE}} ({{EMAIL_ADDRESS}})
 * @brief     helper header file
 * @version   0.1
 * @date      {{DATE}}
 * @copyright Copyright (c) {{YEAR}}
 *
 * <a href="https://github.com/{{GITHUB_PROFILE}}/{{PROJECT_NAME}}/project/inc/helper.h">helper.h</a>
 */

//? Pre-Processor prototype declaration part
#ifndef __HELPER_H__
#define __HELPER_H__

// #########################################
// ### HEADERS & MACROS DECLARATION PART ###
// #########################################

#include <stdio.h>
#include <stdlib.h>

// ################################
// ### STRUCTS DECLARATION PART ###
// ################################

/*
 * struct...
 */

// ##################################
// ### FUNCTIONS DECLARATION PART ###
// ##################################

/*
 * func...
 */

#endif // __HELPER_H__
