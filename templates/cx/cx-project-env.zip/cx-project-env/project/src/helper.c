/**
 * @file      helper.c
 * @author    {{GITHUB_PROFILE}} ({{EMAIL_ADDRESS}})
 * @brief     helper source file
 * @version   0.1
 * @date      {{DATE}}
 * @copyright Copyright (c) {{YEAR}}
 *
 * <a href="https://github.com/{{GITHUB_PROFILE}}/{{PROJECT_NAME}}/project/src/helper.c">helper.c</a>
 */

#include "../inc/helper.h"

/*
 * function() {...}
 */
