/**
 * @file      main.c
 * @author    {{GITHUB_PROFILE}} ({{EMAIL_ADDRESS}})
 * @brief     main source file
 * @version   0.1
 * @date      {{DATE}}
 * @copyright Copyright (c) {{YEAR}}
 *
 * <a href="https://github.com/{{GITHUB_PROFILE}}/{{PROJECT_NAME}}/project/src/main.c">main.c</a>
 */

#include "../inc/helper.h"

/**
 * @fn         main(int, const char **)
 * @brief      Entry point
 * @param argc Argument count
 * @param argv Argument vector
 * @return     EXIT_SUCCESS
 */
int main(int argc, const char **argv) {
  printf("Hello World!\n");
  return EXIT_SUCCESS;
}
