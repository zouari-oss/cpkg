#!/usr/bin/env bash

# Prompt for input
read -rp "Enter Project name: " PROJECT_NAME
read -rp "Enter GitHub profile (optional): " GITHUB_PROFILE
read -rp "Enter Email address (optional): " EMAIL_ADDRESS

# Set default values for optional fields
: "${GITHUB_PROFILE:=Not specified}"
: "${EMAIL_ADDRESS:='no-email@example.com'}"

# Get current date
DATE=$(date +"%Y-%m-%d")
YEAR=$(date +"%Y")

# Validate PROJECT_NAME
if [ -z "$PROJECT_NAME" ]; then
  echo "[ERROR] Project name cannot be empty!"
  exit 1
fi

# Template directory
TEMPLATE_DIR="cx-contest-env"

if [ ! -d "$TEMPLATE_DIR" ]; then
  echo "[ERROR] Template directory '${TEMPLATE_DIR}' does not exist!"
  exit 1
fi

# Rename template directory
mv "$TEMPLATE_DIR" "${PROJECT_NAME}"

# Target file
TARGET_FILE="${PROJECT_NAME}/template.c"

if [ ! -f "${TARGET_FILE}" ]; then
  echo "[WARNING] File '${TARGET_FILE}' not found!"
fi

# Replace placeholders in TARGET_FILE
sed -i \
  -e "s|{{PROJECT_NAME}}|$PROJECT_NAME|g" \
  -e "s|{{GITHUB_PROFILE}}|$GITHUB_PROFILE|g" \
  -e "s|{{EMAIL_ADDRESS}}|$EMAIL_ADDRESS|g" \
  -e "s|{{DATE}}|$DATE|g" \
  -e "s|{{YEAR}}|$YEAR|g" "${TARGET_FILE}"
