@echo off
setlocal enabledelayedexpansion

:: Prompt for input
set /p PROJECT_NAME=Enter Project name: 
set /p GITHUB_PROFILE=Enter GitHub profile (optional): 
set /p EMAIL_ADDRESS=Enter Email address (optional): 

:: Set default values
if "%GITHUB_PROFILE%"=="" set "GITHUB_PROFILE=Not specified"
if "%EMAIL_ADDRESS%"=="" set "EMAIL_ADDRESS=no-email@example.com"

:: Get current date
for /f "tokens=2 delims==" %%I in ('wmic os get LocalDateTime /value') do set ldt=%%I
set DATE=!ldt:~0,4!-!ldt:~4,2!-!ldt:~6,2!
set YEAR=!ldt:~0,4!

:: Validate PROJECT_NAME
if "%PROJECT_NAME%"=="" (
    echo [ERROR] Project name cannot be empty!
    exit /b 1
)

:: Template file
set "TEMPLATE_FILE=java-code-practice-env.java"

if not exist "%TEMPLATE_FILE%" (
    echo [ERROR] Template file "%TEMPLATE_FILE%" not found!
    exit /b 1
)

:: Target file
set "TARGET_FILE=%PROJECT_NAME%.java"

:: Rename template file
ren "%TEMPLATE_FILE%" "%TARGET_FILE%"

:: Replace placeholders in TARGET_FILE
powershell -Command ^
    "(Get-Content -Raw -LiteralPath '%TARGET_FILE%') ^
    -replace '\{\{PROJECT_NAME\}\}', '%PROJECT_NAME%' ^
    -replace '\{\{GITHUB_PROFILE\}\}', '%GITHUB_PROFILE%' ^
    -replace '\{\{EMAIL_ADDRESS\}\}', '%EMAIL_ADDRESS%' ^
    -replace '\{\{DATE\}\}', '%DATE%' ^
    -replace '\{\{YEAR\}\}', '%YEAR%' ^
    | Set-Content -LiteralPath '%TARGET_FILE%'"

pause
