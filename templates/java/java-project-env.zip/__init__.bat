@echo off
setlocal enabledelayedexpansion

:: Prompt for input
set /p PROJECT_NAME=Enter Project name: 
set /p PROJECT_DESC=Enter Project description (optional): 
set /p GITHUB_PROFILE=Enter GitHub profile (optional): 
set /p LINKEDIN_PROFILE=Enter Linkedin profile (optional): 
set /p EMAIL_ADDRESS=Enter Email address (optional): 

:: Set default values
if "%PROJECT_DESC%"=="" set "PROJECT_DESC=No description provided"
if "%GITHUB_PROFILE%"=="" set "GITHUB_PROFILE=Not specified"
if "%LINKEDIN_PROFILE%"=="" set "LINKEDIN_PROFILE=Not specified"
if "%EMAIL_ADDRESS%"=="" set "EMAIL_ADDRESS=no-email@example.com"

:: Get current date
for /f "tokens=2 delims==" %%I in ('wmic os get LocalDateTime /value') do set ldt=%%I
set DATE=!ldt:~0,4!-!ldt:~4,2!-!ldt:~6,2!
set YEAR=!ldt:~0,4!

:: Validate PROJECT_NAME
if "%PROJECT_NAME%"=="" (
    echo [ERROR] Project name cannot be empty!
    exit /b 1
)

:: Template directory
set "TEMPLATE_DIR=java-project-env"

if not exist "%TEMPLATE_DIR%" (
    echo [ERROR] Template directory "%TEMPLATE_DIR%" does not exist!
    exit /b 1
)

:: Rename root folder
ren "%TEMPLATE_DIR%" "%PROJECT_NAME%"

:: Replace placeholders in all files recursively
for /r "%PROJECT_NAME%" %%F in (*) do (
    set "file=%%F"
    powershell -Command ^
        "(Get-Content -Raw -LiteralPath '!file!') ^
        -replace '\{\{PROJECT_NAME\}\}', '!PROJECT_NAME!' ^
        -replace '\{\{PROJECT_DESC\}\}', '!PROJECT_DESC!' ^
        -replace '\{\{GITHUB_PROFILE\}\}', '!GITHUB_PROFILE!' ^
        -replace '\{\{LINKEDIN_PROFILE\}\}', '!LINKEDIN_PROFILE!' ^
        -replace '\{\{EMAIL_ADDRESS\}\}', '!EMAIL_ADDRESS!' ^
        -replace '\{\{DATE\}\}', '!DATE!' ^
        -replace '\{\{YEAR\}\}', '!YEAR!' ^
        | Set-Content -LiteralPath '!file!'"
)

pause
