#!/usr/bin/env bash

# Prompt for input
read -rp "Enter Project name: " PROJECT_NAME
read -rp "Enter GitHub profile (optional): " GITHUB_PROFILE
read -rp "Enter Email address (optional): " EMAIL_ADDRESS

# Set default values for optional fields
: "${GITHUB_PROFILE:=Not specified}"
: "${EMAIL_ADDRESS:='no-email@example.com'}"

# Get current date
DATE=$(date +"%Y-%m-%d")
YEAR=$(date +"%Y")

# Validate PROJECT_NAME
if [ -z "$PROJECT_NAME" ]; then
  echo "[ERROR] Project name cannot be empty!"
  exit 1
fi

# Template file
TEMPLATE_FILE="cxx-code-practice-env.cpp"

if [ ! -f "${TEMPLATE_FILE}" ]; then
  echo "[ERROR] Template file '${TEMPLATE_FILE}' not found!"
  exit 1
fi

# Target file
TARGET_FILE="${PROJECT_NAME}.cpp"

# Rename file template
mv "$TEMPLATE_FILE" "${TARGET_FILE}"

# Replace placeholders in TARGET_FILE
sed -i \
  -e "s|{{PROJECT_NAME}}|$PROJECT_NAME|g" \
  -e "s|{{GITHUB_PROFILE}}|$GITHUB_PROFILE|g" \
  -e "s|{{EMAIL_ADDRESS}}|$EMAIL_ADDRESS|g" \
  -e "s|{{DATE}}|$DATE|g" \
  -e "s|{{YEAR}}|$YEAR|g" "${TARGET_FILE}"
