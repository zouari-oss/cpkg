@echo off
setlocal enabledelayedexpansion

:: Prompt for input
set /p PROJECT_NAME=Enter Project name: 
set /p PROJECT_DESC=Enter Project description (optional): 
set /p GITHUB_PROFILE=Enter GitHub profile (optional): 
set /p LINKEDIN_PROFILE=Enter Linkedin profile (optional): 
set /p EMAIL_ADDRESS=Enter Email address (optional): 

:: Set default values for optional fields
if "%PROJECT_DESC%"=="" set "PROJECT_DESC=No description provided"
if "%GITHUB_PROFILE%"=="" set "GITHUB_PROFILE=Not specified"
if "%LINKEDIN_PROFILE%"=="" set "LINKEDIN_PROFILE=Not specified"
if "%EMAIL_ADDRESS%"=="" set "EMAIL_ADDRESS=no-email@example.com"

:: Get current date
for /f "tokens=2 delims==" %%I in ('wmic os get LocalDateTime /value') do set ldt=%%I
set DATE=!ldt:~0,4!-!ldt:~4,2!-!ldt:~6,2!
set YEAR=!ldt:~0,4!

:: Validate project name
if "%PROJECT_NAME%"=="" (
    echo [ERROR] Project name cannot be empty!
    exit /b 1
)

:: Rename template folder
if not exist "cxx-qt-project-env" (
    echo [ERROR] Template folder "cx-project-env" does not exist!
    exit /b 1
)
ren "cx-project-env" "%PROJECT_NAME%"

:: Replace placeholders in file contents only
for /r "%PROJECT_NAME%" %%F in (*) do (
    set "file=%%F"
    powershell -Command ^
        "(Get-Content -Raw -LiteralPath '!file!') -replace '\{\{PROJECT_NAME\}\}', [regex]::Escape('$PROJECT_NAME')" ^
        " -replace '\{\{PROJECT_DESC\}\}', [regex]::Escape('$PROJECT_DESC')" ^
        " -replace '\{\{GITHUB_PROFILE\}\}', [regex]::Escape('$GITHUB_PROFILE')" ^
        " -replace '\{\{LINKEDIN_PROFILE\}\}', [regex]::Escape('$LINKEDIN_PROFILE')" ^
        " -replace '\{\{EMAIL_ADDRESS\}\}', [regex]::Escape('$EMAIL_ADDRESS')" ^
        " -replace '\{\{DATE\}\}', '$DATE'" ^
        " -replace '\{\{YEAR\}\}', '$YEAR' | Set-Content -LiteralPath '!file!'"
)

pause
