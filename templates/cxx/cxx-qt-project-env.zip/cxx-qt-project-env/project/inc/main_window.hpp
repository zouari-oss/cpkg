/**
 * @file      main_window.hpp
 * @author    {{GITHUB_PROFILE}} ({{EMAIL_ADDRESS}})
 * @brief     main_window header file
 * @version   0.1
 * @date      {{DATE}}
 * @copyright Copyright (c) {{YEAR}}
 *
 * <a href="https://github.com/{{GITHUB_PROFILE}}/{{PROJECT_NAME}}/project/inc/main_window.hpp">main_window.hpp</a>
 */

//? Pre-Processor prototype declaration part
#ifndef __MAINWINDOW_HPP__
#define __MAINWINDOW_HPP__

// #############################################
// ### HEADER(S) & MACRO(S) DECLARATION PART ###
// #############################################

#include "../ui/ui_main_window.h"
#include <qt6/QtWidgets/QtWidgets>

// ##################################
// ### STRUCT(S) DECLARATION PART ###
// ##################################

/*
 * struct...
 */

// ##############################################
// ### CLASSE(S)/FUNCTION(S) DECLARATION PART ###
// ##############################################

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

/**
 * @class MainWindow
 * @brief MainWindow class
 */
class MainWindow : public QMainWindow {
  Q_OBJECT

public:
  MainWindow(QWidget *parent = nullptr);
  ~MainWindow();

private:
  Ui::MainWindow *ui;
}; // MainWindow class

#endif // __MAINWINDOW_HPP__
