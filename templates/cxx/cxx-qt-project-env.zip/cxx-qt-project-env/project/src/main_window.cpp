/**
 * @file      main_window.cpp
 * @author    {{GITHUB_PROFILE}} ({{EMAIL_ADDRESS}})
 * @brief     main_window source file
 * @version   0.1
 * @date      {{DATE}}
 * @copyright Copyright (c) {{YEAR}}
 *
 * <a href="https://github.com/{{GITHUB_PROFILE}}/{{PROJECT_NAME}}/project/src/main_window.cpp">main_window.cpp</a>
 */

#include "../inc/main_window.hpp"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow) {
  ui->setupUi(this);
}

MainWindow::~MainWindow() {
  delete ui;
}
