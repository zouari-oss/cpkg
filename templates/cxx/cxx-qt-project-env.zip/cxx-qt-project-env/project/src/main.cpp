/**
 * @file      main.cpp
 * @author    {{GITHUB_PROFILE}} ({{EMAIL_ADDRESS}})
 * @brief     main source file
 * @version   0.1
 * @date      {{DATE}}
 * @copyright Copyright (c) {{YEAR}}
 *
 * <a href="https://github.com/{{GITHUB_PROFILE}}/{{PROJECT_NAME}}/project/src/main.cpp">main.cpp</a>
 */

#include "../inc/main_window.hpp"
#include <qt6/QtWidgets/QApplication>

/**
 * @fn         main(int, const char **)
 * @brief      Entry point
 * @param argc Argument count
 * @param argv Argument vector
 * @return     EXIT_SUCCESS
 */
int main(int argc, char *argv[]) {
  QApplication app(argc, argv);
  MainWindow w;
  w.show();
  return app.exec();
}
