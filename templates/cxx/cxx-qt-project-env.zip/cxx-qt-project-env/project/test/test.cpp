/**
 * @file      test.cpp
 * @author    {{GITHUB_PROFILE}} ({{EMAIL_ADDRESS}})
 * @brief     test file
 * @version   0.1
 * @date      {{DATE}}
 * @copyright Copyright (c) {{YEAR}}
 *
 * <a href="https://github.com/{{GITHUB_PROFILE}}/{{PROJECT_NAME}}/project/test/test.cpp">test.cpp</a>
 */

#include "../inc/main_window.hpp"
#include <gtest/gtest.h>

/**
 * @brief The Main Testing Function
 *
 * @details This is the entry point for running all the Google Tests in the project.
 *
 * @param argc {int}     Number of command-line arguments.
 * @param argv {char **} Array of command-line argument strings.
 *
 * @return int Returns the result of running all tests (0 if all tests passed, non-zero if any failed).
 */
int main(int argc, char **argv) {
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

/**
 * @brief Simple test case that demonstrates basic output
 *
 * @details This test is used to ensure that a basic output function works as expected.
 *
 * @param TestFn00 test_suite_name
 * @param Test00   test_name
 */
TEST(TestFn00, Test00) {
  std::cout << "Test True!" << std::endl; // This is just a simple print statement for testing purposes
}
