#!/usr/bin/env bash

# Prompt for input
read -rp "Enter Project name: " PROJECT_NAME
read -rp "Enter Project description (optional): " PROJECT_DESC
read -rp "Enter GitHub profile (optional): " GITHUB_PROFILE
read -rp "Enter Linkedin profile (optional): " LINKEDIN_PROFILE
read -rp "Enter Email address (optional): " EMAIL_ADDRESS

# Set default values for optional fields
: "${PROJECT_DESC:='No description provided'}"
: "${GITHUB_PROFILE:=Not specified}"
: "${LINKEDIN_PROFILE:=Not specified}"
: "${EMAIL_ADDRESS:='no-email@example.com'}"

# Get current date
DATE=$(date +"%Y-%m-%d")
YEAR=$(date +"%Y")

# Validate PROJECT_NAME
if [ -z "$PROJECT_NAME" ]; then
  echo "[ERROR] Project name cannot be empty!"
  exit 1
fi

# Template directory
TEMPLATE_DIR="cxx-qt-project-env"

if [ ! -d "$TEMPLATE_DIR" ]; then
  echo "[ERROR] Template directory '$TEMPLATE_DIR' does not exist!"
  exit 1
fi

# Rename only root project folder
mv "$TEMPLATE_DIR" "$PROJECT_NAME"

# Function to replace placeholders in file contents
replace_in_file_contents() {
  local file="$1"
  if [ -f "$file" ]; then
    sed -i \
      -e "s|{{PROJECT_NAME}}|$PROJECT_NAME|g" \
      -e "s|{{PROJECT_DESC}}|$PROJECT_DESC|g" \
      -e "s|{{GITHUB_PROFILE}}|$GITHUB_PROFILE|g" \
      -e "s|{{LINKEDIN_PROFILE}}|$LINKEDIN_PROFILE|g" \
      -e "s|{{EMAIL_ADDRESS}}|$EMAIL_ADDRESS|g" \
      -e "s|{{DATE}}|$DATE|g" \
      -e "s|{{YEAR}}|$YEAR|g" "$file"
  fi
}

# Replace placeholders in all files
find "$PROJECT_NAME" -type f | while read -r file; do
  replace_in_file_contents "$file"
done
