#!/usr/bin/env bash

set -e

# Prompt for input
read -rp "[1/7] Enter Project name: " PROJECT_NAME
read -rp "[2/7] Enter Project description (optional): " PROJECT_DESC
read -rp "[3/7] Enter Author name (optional): " AUTHOR_NAME
read -rp "[4/7] Enter Git provider (optional): " REMOTE_PROVIDER
read -rp "[5/7] Enter username/org name (optional): " USER_NAME
read -rp "[6/7] Enter Linkedin profile (optional): " LINKEDIN_PROFILE
read -rp "[7/7] Enter Email address (optional): " EMAIL_ADDRESS

# Defaults
: "${PROJECT_DESC:='No description provided'}"
: "${AUTHOR_NAME:=Unknown}"
: "${REMOTE_PROVIDER:=github.com}"
: "${USER_NAME:=Unknown}"
: "${LINKEDIN_PROFILE:=Unknown}"
: "${EMAIL_ADDRESS:='no-email@example.com'}"

# Date info
DATE=$(date +"%Y-%m-%d")
YEAR=$(date +"%Y")

# Validate project name input
if [ -z "$PROJECT_NAME" ]; then
  echo "[ERROR] Project name cannot be empty!"
  exit 1
fi

# Template directory
TEMPLATE_DIR="go-project-env"

if [ ! -d "$TEMPLATE_DIR" ]; then
  echo "[ERROR] Template directory '$TEMPLATE_DIR' does not exist!"
  exit 1
fi

# Build module path automatically
MODULE_PATH="${REMOTE_PROVIDER}/${USER_NAME}/${PROJECT_NAME}"

echo "[INFO] Using module path: $MODULE_PATH"

# Check Go installation
if ! command -v go >/dev/null 2>&1; then
  echo "[ERROR] Go is not installed. Please install Go first."
  exit 1
fi

echo "[INFO] Go found: $(go version)"

# Check go-blueprint installation
if ! command -v go-blueprint >/dev/null 2>&1; then
  echo "[INFO] go-blueprint not found. Installing..."
  go install github.com/melkeydev/go-blueprint@latest

  if ! command -v go-blueprint >/dev/null 2>&1; then
    echo "[ERROR] go-blueprint installation failed."
    exit 1
  fi

  echo "[SUCCESS] go-blueprint installed."
fi

# Prevent overwrite
if [ -d "$PROJECT_NAME" ]; then
  echo "[ERROR] Directory '$PROJECT_NAME' already exists!"
  exit 1
fi

# Rename only root project folder
mv "$TEMPLATE_DIR" "$PROJECT_NAME"

# Run blueprint
echo "[INFO] Running go-blueprint..."
cd "$PROJECT_NAME" && go-blueprint create -n project

# Replace placeholders in all project files
find . -type f \( -name "*.go" -o -name "*.md" -o -name "*.yaml" -o -name "*.yml" -o -name "*.txt" \) \
  -exec sed -i \
  -e "s|{{PROJECT_NAME}}|$PROJECT_NAME|g" \
  -e "s|{{PROJECT_DESC}}|$PROJECT_DESC|g" \
  -e "s|{{AUTHOR_NAME}}|$AUTHOR_NAME|g" \
  -e "s|{{MODULE_PATH}}|$MODULE_PATH|g" \
  -e "s|{{REMOTE_PROVIDER}}|$REMOTE_PROVIDER|g" \
  -e "s|{{USER_NAME}}|$USER_NAME|g" \
  -e "s|{{LINKEDIN_PROFILE}}|$LINKEDIN_PROFILE|g" \
  -e "s|{{EMAIL_ADDRESS}}|$EMAIL_ADDRESS|g" \
  -e "s|{{DATE}}|$DATE|g" \
  -e "s|{{YEAR}}|$YEAR|g" {} +

echo "[SUCCESS] Project '$PROJECT_NAME' created successfully."
