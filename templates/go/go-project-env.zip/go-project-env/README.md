[![Contributors](https://img.shields.io/badge/CONTRIBUTORS-01-blue?style=plastic)](https://{{MODULE_PATH}}/graphs/contributors)
[![Forks](https://img.shields.io/badge/FORKS-00-blue?style=plastic)](https://github.com/{{GITHUB_PROFILE}}/{{PROJECT_NAME}}/network/members)
[![Stargazers](https://img.shields.io/badge/STARS-01-blue?style=plastic)](https://github.com/{{MODULE_PATH}/stargazers)
[![Issues](https://img.shields.io/badge/ISSUES-00-blue?style=plastic)](https://github.com/{{MODULE_PATH}}/issues)
[![GPL3.0 License](https://img.shields.io/badge/LICENSE-GPL3.0-blue?style=plastic)](https://raw.githubusercontent.com/{{MODULE_PATH}}/refs/heads/main/LICENSE)
[![Linkedin](https://img.shields.io/badge/Linkedin-6.9k-blue?style=plastic)](https://www.linkedin.com/in/{{LINKEDIN_PROFILE}})

<div align="center">
  <a href="https://github.com/zouari-oss/crun">
    <img src="https://{{MODULE_PATH}}/raw/main/res/img/logo.png" alt="crun-logo" width="300">
  </a>
  <h1>{{PROJECT_NAME}}</h1>
  <h4>{{PROJECT_DESC}}</h4>
  <br />
</div>

<p align="center">
  <a href="#overview">Overview</a> •
  <a href="#key-features">Key Features</a> •
  <a href="#usage">Usage</a> •
  <a href="#download">Download</a> •
  <a href="#emailware">Emailware</a> •
  <a href="#contributing">Contributing</a> •
  <a href="#license">License</a> •
  <a href="#contact">Contact</a> •
  <a href="#acknowledgments">Acknowledgments</a>
</p>

<p align="center">
  <img src="https://img.shields.io/badge/java-%23ED8B00.svg?style=for-the-badge&logo=openjdk&logoColor=white"/>
  <img src="https://img.shields.io/badge/openjdk-000000?style=for-the-badge&logo=openjdk&logoColor=white"/>
  <img src="https://img.shields.io/badge/jvm-ED8B00?style=for-the-badge&logo=java&logoColor=white"/>
  <img src="https://img.shields.io/badge/junit5-25A162?style=for-the-badge&logo=java&logoColor=white"/>
  <img src="https://img.shields.io/badge/apache_maven-C71A36?style=for-the-badge&logo=apache-maven&logoColor=white"/>
  <img src="https://img.shields.io/badge/bash_script-%23121011.svg?style=for-the-badge&logo=gnu-bash&logoColor=white"/>
  <img src="https://img.shields.io/badge/Cross--Platform-Yes-success?style=for-the-badge"/>
  <img src="https://img.shields.io/badge/Open%20Source-3DA639?style=for-the-badge&logo=opensourceinitiative&logoColor=white"/>
</p>

![screenshot](https://github.com/{{GITHUB_PROFILE}}/{{PROJECT_NAME}}/raw/main/res/img/screenshot.png)

## Overview

Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.

## Key Features

Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.

- [CMake](https://cmake.org)
- [Ninja](https://github.com/ninja-build/ninja)

## Usage

```bash
git clone https://{{MODULE_PATH}}
cd {{PROJECT_NAME}}/project

makefile build run
```

## Download

You can [download](https://github.com/{{MODULE_PATH}}/releases) the latest installable version of {{PROJECT_NAME}} for Windows, macOS and Linux.

## Emailware

{{PROJECT_NAME}} is an emailware. Meaning, if you liked using this app or it has helped you in any way,
would like you send as an email at <{{EMAIL_ADDRESS}}> about anything you'd want to say about
this software. I'd really appreciate it!

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This repository is licensed under the **GPL-3.0 License**. You are free to use, modify, and distribute the content. See the [LICENSE](LICENSE) file for details.

## Contact

For questions or suggestions, feel free to reach out:

- **{{REMOTE_PROVIDER}}**: [{{GITHUB_PROFILE}}](https://{{MODULE_PATH}})
- **Email**: <{{EMAIL_ADDRESS}}>
- **LinkedIn**: [{{LINKEDIN_PROFILE}}](https://www.linkedin.com/in/{{LINKEDIN_PROFILE}})

## Acknowledgments

Built with ❤️ for the open-source community.
