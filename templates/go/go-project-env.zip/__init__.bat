@echo off
setlocal enabledelayedexpansion

:: Prompt for input
set /p "PROJECT_NAME=[1/7] Enter Project name: "
set /p "PROJECT_DESC=[2/7] Enter Project description (optional): "
set /p "AUTHOR_NAME=[3/7] Enter Author name (optional): "
set /p "REMOTE_PROVIDER=[4/7] Enter Git provider (optional): "
set /p "USER_NAME=[5/7] Enter username/org name (optional): "
set /p "LINKEDIN_PROFILE=[6/7] Enter Linkedin profile (optional): "
set /p "EMAIL_ADDRESS=[7/7] Enter Email address (optional): "

:: Defaults
if "%PROJECT_DESC%"=="" set "PROJECT_DESC=No description provided"
if "%AUTHOR_NAME%"=="" set "AUTHOR_NAME=Unknown"
if "%REMOTE_PROVIDER%"=="" set "REMOTE_PROVIDER=github.com"
if "%USER_NAME%"=="" set "USER_NAME=Unknown"
if "%LINKEDIN_PROFILE%"=="" set "LINKEDIN_PROFILE=Unknown"
if "%EMAIL_ADDRESS%"=="" set "EMAIL_ADDRESS=no-email@example.com"

:: Date info
for /f "tokens=2-4 delims=/ " %%a in ('date /t') do set DATE=%%c-%%a-%%b
set YEAR=%DATE:~0,4%

:: Validate project name input
if "%PROJECT_NAME%"=="" (
    echo [ERROR] Project name cannot be empty!
    exit /b 1
)

:: Template directory
set TEMPLATE_DIR=go-project-env

if not exist "%TEMPLATE_DIR%\" (
    echo [ERROR] Template directory '%TEMPLATE_DIR%' does not exist!
    exit /b 1
)

:: Build module path
set MODULE_PATH=%REMOTE_PROVIDER%/%USER_NAME%/%PROJECT_NAME%
echo [INFO] Using module path: %MODULE_PATH%

:: Check Go installation
where go >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Go is not installed. Please install Go first.
    exit /b 1
)
for /f "delims=" %%i in ('go version') do set GO_VERSION=%%i
echo [INFO] Go found: %GO_VERSION%

:: Check go-blueprint installation
where go-blueprint >nul 2>&1
if %errorlevel% neq 0 (
    echo [INFO] go-blueprint not found. Installing...
    go install github.com/melkeydev/go-blueprint@latest
    where go-blueprint >nul 2>&1
    if %errorlevel% neq 0 (
        echo [ERROR] go-blueprint installation failed.
        exit /b 1
    )
    echo [SUCCESS] go-blueprint installed.
)

:: Prevent overwrite
if exist "%PROJECT_NAME%\" (
    echo [ERROR] Directory '%PROJECT_NAME%' already exists!
    exit /b 1
)

:: Rename template directory
ren "%TEMPLATE_DIR%" "%PROJECT_NAME%"

:: Run go-blueprint
echo [INFO] Running go-blueprint...
cd "%PROJECT_NAME%"
go-blueprint create -n project
cd ..

:: Replace placeholders in all project files using PowerShell
powershell -Command "
$projectName = '%PROJECT_NAME%';
$projectDesc = '%PROJECT_DESC%';
$authorName = '%AUTHOR_NAME%';
$modulePath = '%MODULE_PATH%';
$remoteProvider = '%REMOTE_PROVIDER%';
$userName = '%USER_NAME%';
$linkedinProfile = '%LINKEDIN_PROFILE%';
$emailAddress = '%EMAIL_ADDRESS%';
$date = '%DATE%';
$year = '%YEAR%';

Get-ChildItem -Path '$projectName' -Recurse -Include *.go,*.md,*.yaml,*.yml,*.txt | ForEach-Object {
    $content = Get-Content $_.FullName -Raw;
    $content = $content -replace '\{\{PROJECT_NAME\}\}', $projectName;
    $content = $content -replace '\{\{PROJECT_DESC\}\}', $projectDesc;
    $content = $content -replace '\{\{AUTHOR_NAME\}\}', $authorName;
    $content = $content -replace '\{\{MODULE_PATH\}\}', $modulePath;
    $content = $content -replace '\{\{REMOTE_PROVIDER\}\}', $remoteProvider;
    $content = $content -replace '\{\{USER_NAME\}\}', $userName;
    $content = $content -replace '\{\{LINKEDIN_PROFILE\}\}', $linkedinProfile;
    $content = $content -replace '\{\{EMAIL_ADDRESS\}\}', $emailAddress;
    $content = $content -replace '\{\{DATE\}\}', $date;
    $content = $content -replace '\{\{YEAR\}\}', $year;
    $content | Set-Content $_.FullName;
}
"

:: Change to the new project directory
cd "%PROJECT_NAME%"
echo [SUCCESS] Project '%PROJECT_NAME%' created successfully.
